import { ResizeObserver } from '@juggle/resize-observer';
window.ResizeObserver = window.ResizeObserver || ResizeObserver;
