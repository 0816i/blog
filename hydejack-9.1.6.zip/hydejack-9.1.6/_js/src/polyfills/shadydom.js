import '@webcomponents/shadydom';
import '@webcomponents/shadycss/entrypoints/scoping-shim';
